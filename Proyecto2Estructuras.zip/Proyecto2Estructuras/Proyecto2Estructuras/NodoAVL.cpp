#include "NodoAVL.h"

NodoAVL::NodoAVL(int valor)
{
	Altura = 0;
	Valor = valor;
	Izquierdo = 0;
	Derecho = 0;

}

void NodoAVL::setaltura(int altura)
{
	Altura = altura;
}

int NodoAVL::getaltura()
{
	return Altura;
}

void NodoAVL::setbalance(int balance)
{
	Balance = balance;
}

int NodoAVL::getbalance()
{
	return Balance;
}

bool NodoAVL::EsHoja()
{
	if (Izquierdo == nullptr && Derecho == nullptr) {
		return true;
	}
	else {
		return false;
	}
}

bool NodoAVL::EsInterno()
{
	if (Izquierdo != nullptr && Derecho != nullptr) {
		return true;
	}
	else {
		return false;
	}
}

int NodoAVL::Grado()
{
	if (Izquierdo == nullptr && Derecho == nullptr) {
		return 0;
	}

	else if (Izquierdo != nullptr && Derecho != nullptr) {
		return 2;
	}

	else {
		return 1;
	}
}

