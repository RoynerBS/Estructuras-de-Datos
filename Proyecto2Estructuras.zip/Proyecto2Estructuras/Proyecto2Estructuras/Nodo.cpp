#include "Nodo.h"

Nodo::Nodo(int valor) {

	Valor = valor;
	Izquierdo = nullptr;
	Derecho = nullptr;

}
