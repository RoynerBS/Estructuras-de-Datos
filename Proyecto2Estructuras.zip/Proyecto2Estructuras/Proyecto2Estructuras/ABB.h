#pragma once
#include "Nodo.h"
#include <iostream>
#include <vector>
#include <time.h>

class ABB
{
public:
	Nodo* Raiz;

	ABB();

	bool Buscar(int x);

	Nodo* Insertar(int x, Nodo* Actual);
	void InsertarIni(int x);
	Nodo* Insertar2(int x);
	void ImprimirIni();
	void Imprimir(Nodo* Actual);

	double ExperimentoABB(int n, std::vector<int> registro);
	double RepetirExperimentoABB(int n, std::vector<int> registro);

};

