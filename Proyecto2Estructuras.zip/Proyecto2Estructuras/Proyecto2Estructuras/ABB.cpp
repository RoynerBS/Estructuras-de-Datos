#include "ABB.h"

ABB::ABB()
{
	Raiz = nullptr;
}

bool ABB::Buscar(int x)
{
	Nodo* Actual = Raiz;
	bool banderaporsialgo = false;
	while (Actual != nullptr) {

		if (Actual->Valor == x) {
			banderaporsialgo = true;
			break;
		}
		else if (x < Actual->Valor) {
			Actual = Actual->Izquierdo;
		}

		else if (x > Actual->Valor) {
			Actual = Actual->Derecho;
		}
		
	}
	if (banderaporsialgo == false){	
		return false;
	}
	else 
	{
		return true;
	}
}

Nodo* ABB::Insertar(int x, Nodo* Actual)
{
	if (Actual == nullptr){
		Nodo* nuevo = new Nodo(x);
		return nuevo;
	}
	else if (x < Actual->Valor){
		Actual->Izquierdo = Insertar(x, Actual->Izquierdo);
		return Actual;
	}
	else if (x > Actual->Valor) {
		Actual->Derecho = Insertar(x, Actual->Derecho);
		return Actual;
	}
}

void ABB::InsertarIni(int x)
{
	Raiz = Insertar(x, Raiz);
}

Nodo* ABB::Insertar2(int x) {

	Nodo* Actual = Raiz;

	if (Raiz == nullptr)
	{
		Actual = new Nodo(x);
		Raiz = Actual;
		return Actual;
	}
	else {
		while (true) {

			if (x < Actual->Valor && Actual->Izquierdo != nullptr) {
				Actual = Actual->Izquierdo;
			}

			else if (x < Actual->Valor && Actual->Izquierdo == nullptr) {
				Actual = Actual->Izquierdo;
				Actual = new Nodo(x);
				return Actual;
				break;
			}

			else if (x > Actual->Valor && Actual->Derecho != nullptr) {
				Actual = Actual->Derecho;
			}

			else if (x > Actual->Valor && Actual->Derecho == nullptr) {
				Actual = Actual->Derecho;
				Actual = new Nodo(x);
				return Actual;
				break;
			}

		}
	}
}

void ABB::ImprimirIni()
{
	Imprimir(Raiz);
}

void ABB::Imprimir(Nodo* Actual)
{
	if (Actual == NULL)
		return;
	Imprimir(Actual->Izquierdo);
	std::cout <<Actual->Valor<<" ";
	Imprimir(Actual->Derecho);
}

double ABB::ExperimentoABB(int n, std::vector<int> registro)
{
	time_t inicio, final;
	inicio = time(0);
	int contador = 0;
	while (contador < n)
	{
		Buscar(registro[contador]);
		contador += 1;
	}
	final = time(0);
	double total = inicio - final;
	return total;
}

double ABB::RepetirExperimentoABB(int n, std::vector<int> registro)
{
	int contador = 0;
	double promedio = 0;
	while (contador <= 30)
	{
		promedio += ExperimentoABB(n, registro);
		contador += 1;
	}
	promedio = promedio / 30;
	return promedio;
}
