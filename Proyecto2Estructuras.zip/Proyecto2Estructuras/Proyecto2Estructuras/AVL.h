#pragma once
#include "NodoAVL.h"
#include <vector>
#include <time.h>

enum class Escenario {
	ArbolVacio,	//0
	SinCambios,
	IzquierdoIzquierdo,		//3
	DerechoDerecho,		//4
	IzquierdoDerecho,		//5
	DerechoIzquierdo		//6
};



class AVL
{
public:
	NodoAVL* Raiz;

	AVL();

	int Buscar(int x);


	void InsertarIni(int x);
	NodoAVL* Insertar(int x, NodoAVL* Actual);


	int AlturaIni();
	int Altura(NodoAVL* nodo);


	NodoAVL* Acomodo(NodoAVL* nodo, int x);
	Escenario DeterminarEscenario(NodoAVL* nodo, int x);
	NodoAVL* ManejarEscenario(NodoAVL* nodo, Escenario a, int x);


	NodoAVL* IzquierdoIzquierdo(NodoAVL* nodo);
	NodoAVL* IzquierdoDerecho(NodoAVL* nodo);
	NodoAVL* DerechoDerecho(NodoAVL* nodo);
	NodoAVL* DerechoIzquierdo(NodoAVL* nodo);


	void ImprimirIni();
	void Imprimir(NodoAVL* Actual);


	double ExperimentoAVL(int n,std::vector<int> registro);
	double RepetirExperimentoAVL(int n, std::vector<int> registro);
};

