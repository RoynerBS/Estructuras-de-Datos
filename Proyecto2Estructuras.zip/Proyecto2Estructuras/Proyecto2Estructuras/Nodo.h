#pragma once
class Nodo
{
public:

	int Valor;
	Nodo* Izquierdo;
	Nodo* Derecho;

	Nodo(int valor);

};

