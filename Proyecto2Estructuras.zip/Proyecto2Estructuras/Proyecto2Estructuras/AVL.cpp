#include "AVL.h"
#include <iostream>


AVL::AVL()
{
	Raiz = nullptr;
}

int AVL::Buscar(int x)
{
	NodoAVL* Actual = Raiz;
	bool banderaporsialgo = false;
	while (Actual != nullptr) {

		if (Actual->Valor == x) {
			return true;
			banderaporsialgo = true;
			break;
		}
		else if (x < Actual->Valor) {
			Actual = Actual->Izquierdo;
		}

		else if (x > Actual->Valor) {
			Actual = Actual->Derecho;
		}

	}
	if (banderaporsialgo == false) {
		return false;
	}
}

void AVL::InsertarIni(int x) 
{
	Raiz = Insertar(x, Raiz);
	AlturaIni();
	Raiz = Acomodo(Raiz, x);
}


NodoAVL* AVL::Insertar(int x, NodoAVL* Actual)
{
	if (Actual == nullptr) {
		NodoAVL* nuevo = new NodoAVL(x);
		return nuevo;
	}
	else if (x < Actual->Valor) {
		Actual->Izquierdo = Insertar(x, Actual->Izquierdo);
		return Actual;
	}
	else if (x > Actual->Valor) {
		Actual->Derecho = Insertar(x, Actual->Derecho);
		return Actual;
	}
}
int AVL::AlturaIni()
{
	return Altura(Raiz);
}

int AVL::Altura(NodoAVL* nodo)
{
	if (nodo == NULL) 
	{
		return -1;
	}

	int AlturaIzquierdo = Altura(nodo->Izquierdo);
	int AlturaDerecho = Altura(nodo->Derecho);
	
	if (AlturaIzquierdo >= AlturaDerecho) 
	{
		nodo->setaltura(AlturaIzquierdo+1);
		nodo->setbalance((AlturaIzquierdo + 1) - AlturaDerecho);
		return AlturaIzquierdo + 1;
	}
	else 
	{
		nodo->setaltura(AlturaDerecho+1);
		nodo->setbalance((AlturaDerecho + 1) - AlturaIzquierdo);
		return AlturaDerecho + 1;
	}
}


NodoAVL* AVL::Acomodo(NodoAVL* nodo, int x)
{
	Escenario a = DeterminarEscenario(Raiz, x);
	return ManejarEscenario(Raiz, a, x);
}

Escenario AVL::DeterminarEscenario(NodoAVL* nodo, int x)
{
	if (nodo == nullptr) 
	{
		return Escenario::ArbolVacio;
	}
	else if (nodo->Balance > 1 && nodo->Izquierdo->Balance > 0) 
	{
		return Escenario::IzquierdoIzquierdo;
	}
	else if (nodo->Balance > 1 && nodo->Izquierdo->Balance <= 0)
	{
		return Escenario::IzquierdoDerecho;
	}
	else if (nodo->Balance < -1 && nodo->Izquierdo->Balance < 0)
	{
		return Escenario::DerechoDerecho;
	}
	else if (nodo->Balance < -1 && nodo->Izquierdo->Balance >= 0)
	{
		return Escenario::DerechoIzquierdo;
	}
	else 
	{
		return Escenario::SinCambios;
	}
}



NodoAVL* AVL::ManejarEscenario(NodoAVL* nodo, Escenario a, int x) 
{
	switch (a) 
	{
	case Escenario::ArbolVacio:
		return nodo;
	case Escenario::IzquierdoIzquierdo:
		return IzquierdoIzquierdo(nodo);
	case Escenario::IzquierdoDerecho:
		return IzquierdoDerecho(nodo);
	case Escenario::DerechoDerecho:
		return DerechoDerecho(nodo);
	case Escenario::DerechoIzquierdo:
		return DerechoIzquierdo(nodo);
	case Escenario::SinCambios:
		return nodo;
	}

}

NodoAVL* AVL::IzquierdoIzquierdo(NodoAVL* nodo)
{
	NodoAVL* b = nodo->Izquierdo;
	NodoAVL* br = nodo->Derecho;
	nodo->Izquierdo = br;
	b->Derecho = nodo;
	return b;
}

NodoAVL* AVL::IzquierdoDerecho(NodoAVL* nodo)
{
	NodoAVL* b = nodo->Izquierdo;
	nodo->Derecho = DerechoDerecho(b);
	return IzquierdoIzquierdo(nodo);
}

NodoAVL* AVL::DerechoDerecho(NodoAVL* nodo)
{
	NodoAVL* b = nodo->Derecho;
	NodoAVL* br = nodo->Izquierdo;
	nodo->Derecho = br;
	b->Izquierdo = nodo;
	return b;
}

NodoAVL* AVL::DerechoIzquierdo(NodoAVL* nodo)
{
	NodoAVL* b = nodo->Derecho;
	nodo->Izquierdo = DerechoDerecho(b);
	return IzquierdoIzquierdo(nodo);
}

void AVL::ImprimirIni()
{
	Imprimir(Raiz);
}

void AVL::Imprimir(NodoAVL* Actual)
{
	if (Actual->Valor == NULL)
		return;
	Imprimir(Actual->Izquierdo);
	std::cout << Actual->Valor << " ";
	Imprimir(Actual->Derecho);
}

double AVL::ExperimentoAVL(int n, const std::vector<int> registro)
{
	time_t inicio, final;
	inicio = time(0);
	int contador = 0;
	while (contador < n)
	{
		Buscar(registro[contador]);
		contador += 1;
	}
	final = time(0);
	double total = inicio - final;
	return total;
}

double AVL::RepetirExperimentoAVL(int n, std::vector<int> registro)
{	
	int contador = 0;
	double promedio = 0;
	while (contador <= 30) 
	{
		promedio += ExperimentoAVL(n, registro);
		contador += 1;
	}
	promedio = promedio / 30;
	return promedio;
}

