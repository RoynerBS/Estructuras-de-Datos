#pragma once
class NodoAVL
{
public:

	int Valor;
	int Altura;
	int Balance;
	NodoAVL* Izquierdo;
	NodoAVL* Derecho;

	NodoAVL (int valor);

	void setaltura(int altura);
	int getaltura();
	
	void setbalance(int balance);
	int getbalance();

	bool EsHoja();

	bool EsInterno();

	int Grado();


};

