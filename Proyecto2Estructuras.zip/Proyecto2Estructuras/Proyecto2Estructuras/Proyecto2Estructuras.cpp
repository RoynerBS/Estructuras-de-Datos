// Proyecto2Estructuras.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>
#include "ABB.h"
#include "AVL.h"
#include <list>
#include <vector>

int main()
{
    std::cout << "Hello World!\n";

    ABB pruebadiezABB;
    AVL pruebadiezAVL;
    std::list<int> listadiez;


    ABB pruebamilABB;
    AVL pruebamilAVL;
    std::list<int> listamil;


    ABB pruebacienABB;
    AVL pruebacienAVL;
    std::list<int> listacien;
    
 
    std::vector<int> registrodiez; //contiene los valores a buscar
    std::vector<int> registromil;
    std::vector<int> registrocien;


   

    int n = 10; //cantidad de numeros, son 10, 1000 y 100000, se utiliza en repetirexperimento
    int m = 1000;
    int c = 100000;


    int contadordiez = 0;
    while (contadordiez <= n)//agregar diez valores a lista, abb y avl
    {
        int num = 1 + rand() % (1000001 - 1);
        listadiez.push_back(num);
        registrodiez.push_back(num);
        pruebadiezAVL.InsertarIni(num);
        pruebadiezABB.InsertarIni(num);
        contadordiez += 1;
    }


    int contadormil = 0;
    while (contadormil <= m)//agregar mil valores a lista, abb y avl
    {
        int num = 1 + rand() % (1000001 - 1);
        listamil.push_back(num);
        registromil.push_back(num);
        pruebamilAVL.InsertarIni(num);
        pruebamilABB.InsertarIni(num);
        contadormil += 1;
    }


    int contadorcien = 0;
    while (contadordiez <= c)//agregar cienmil valores a lista, abb y avl
    {
        int num = 1 + rand() % (1000001 - 1);
        listacien.push_back(num);
        registrocien.push_back(num);
        pruebacienAVL.InsertarIni(num);
        pruebacienABB.InsertarIni(num);
        contadorcien += 1;
    }

    //Buscar en lista, repetir 30 veces y tirar promedio


    //diez
    int cantidadvecesdiez = 0;
    double promediodiez = 0;
    while (cantidadvecesdiez <= 30) 
    {
        time_t listadiezinicio, listadiezfinal;
        listadiezinicio = time(0);
        int indicediez = 0;
        while (indicediez < n)
        {
            std::list<int>::iterator findIter = std::find(listadiez.begin(), listadiez.end(), registrodiez[indicediez]);
            indicediez += 1;
        }
        listadiezfinal = time(0);
        double tiempodieztotal = listadiezinicio - listadiezfinal;
        promediodiez += tiempodieztotal;
        cantidadvecesdiez += 1;
    }
    promediodiez = promediodiez / 30;
    std::cout << promediodiez;
    //--------

    //mil
    int cantidadvecesmil = 0;
    double promediomil = 0;
    while (cantidadvecesmil <= 30)
    {
        time_t listamilinicio, listamilfinal;
        listamilinicio = time(0);
        int indicemil = 0;
        while (indicemil < m)
        {
            std::list<int>::iterator findItera = std::find(listamil.begin(), listamil.end(), registromil[indicemil]);
            indicemil += 1;
        }
        listamilfinal = time(0);
        double tiempomiltotal = listamilinicio - listamilfinal;
        promediomil += tiempomiltotal;
        cantidadvecesmil += 1;
    }
    promediomil = promediomil / 30;
    std::cout << promediomil;
    //*---

    //cienmil
    int cantidadvecescien = 0;
    double promediocien = 0;
    while (cantidadvecescien <= 30)
    {
        time_t listacieninicio, listacienfinal;
        listacieninicio = time(0);
        int indicecien = 0;
        while (indicecien < c)
        {
            std::list<int>::iterator findIterar = std::find(listacien.begin(), listacien.end(), registrocien[indicecien]);
            indicecien += 1;
        }
        listacienfinal = time(0);
        double tiempocientotal = listacieninicio - listacienfinal;
        promediocien += tiempocientotal;
        cantidadvecescien += 1;
    }
    promediocien = promediocien / 30;
    std::cout << promediocien;
    //------------


    //buscar en abb y avl 30 veces en 10 1000 y 100000 numeros
    std::cout << pruebadiezAVL.RepetirExperimentoAVL(n, registrodiez);
    std::cout << pruebadiezABB.RepetirExperimentoABB(n, registrodiez);

    std::cout << pruebamilAVL.RepetirExperimentoAVL(m, registromil);
    std::cout << pruebamilABB.RepetirExperimentoABB(m, registromil);

    std::cout << pruebacienAVL.RepetirExperimentoAVL(c, registrocien);
    std::cout << pruebacienABB.RepetirExperimentoABB(c, registrocien);

}


// Ejecutar programa: Ctrl + F5 o menú Depurar > Iniciar sin depurar
// Depurar programa: F5 o menú Depurar > Iniciar depuración

// Sugerencias para primeros pasos: 1. Use la ventana del Explorador de soluciones para agregar y administrar archivos
//   2. Use la ventana de Team Explorer para conectar con el control de código fuente
//   3. Use la ventana de salida para ver la salida de compilación y otros mensajes
//   4. Use la ventana Lista de errores para ver los errores
//   5. Vaya a Proyecto > Agregar nuevo elemento para crear nuevos archivos de código, o a Proyecto > Agregar elemento existente para agregar archivos de código existentes al proyecto
//   6. En el futuro, para volver a abrir este proyecto, vaya a Archivo > Abrir > Proyecto y seleccione el archivo .sln
