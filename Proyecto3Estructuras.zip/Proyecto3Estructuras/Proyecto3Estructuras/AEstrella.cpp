#include "AEstrella.h"

void AEstrella::Inicializar(Grafo& grafo, int fuente)
{
}

void AEstrella::Ejecutar(Grafo& grafo, int fuente)
{
}

int AEstrella::EncontrarMinimioSinVisitar()
{
	return 0;
}

std::string AEstrella::RutaMasCortaA(Grafo& grafo, int destino)
{
	std::string temp = "F";
	std::stringstream ss(temp);
	return ss.str();
}
