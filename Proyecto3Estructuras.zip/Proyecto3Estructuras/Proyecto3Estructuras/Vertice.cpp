#include "Vertice.h"

Vertice::Vertice(int id, std::string nombre, double latitud, double longitud)
{
	Id = id;
	Nombre = nombre;
	latitud = latitud;
	Longitud = longitud;
}

Vertice::~Vertice()
{
}
