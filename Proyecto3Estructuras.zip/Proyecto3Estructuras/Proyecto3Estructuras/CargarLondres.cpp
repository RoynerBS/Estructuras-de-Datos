#include "CargarLondres.h"

CargarLondres::CargarLondres(std::string archivoEstaciones, std::string archivoConexiones)
{
	ArchivoEstaciones = archivoEstaciones;
	ArchivoConexiones = archivoConexiones;
}

void CargarLondres::Cargar(Grafo& londres)
{
	LectorCSV lectorEstaciones = LectorCSV(ArchivoEstaciones);
	std::vector<std::vector<std::string> > estaciones = lectorEstaciones.getData();//??
	
	int recorrerEstaciones = 1;
	while (recorrerEstaciones < estaciones.size()) 
	{
		int cantidad = estaciones.size();
		londres.AgregarVertice(atoi(estaciones[recorrerEstaciones][0].c_str()),estaciones[recorrerEstaciones][3],atof(estaciones[recorrerEstaciones][1].c_str()),atof(estaciones[recorrerEstaciones][2].c_str()));
		recorrerEstaciones += 1;
	}

	int recorrerConexiones = 1;
	LectorCSV lectorConexiones = LectorCSV(ArchivoConexiones);
	std::vector<std::vector<std::string> > conexiones = lectorConexiones.getData();//??
	while (recorrerConexiones < conexiones.size()) 
	{
		londres.AgregarArista(atoi(conexiones[recorrerConexiones][0].c_str()),atoi(conexiones[recorrerConexiones][1].c_str()),atoi(conexiones[recorrerConexiones][2].c_str()), atoi(conexiones[recorrerConexiones][3].c_str()));
		recorrerConexiones += 1;
	}

	//R?


	//codigo donde agrega al grafo londres sus vertices y aristas.


	// recorrer las estaciones y agregarlas como vertices
	// recorres las conexiones y agregarlas como aristas

}
