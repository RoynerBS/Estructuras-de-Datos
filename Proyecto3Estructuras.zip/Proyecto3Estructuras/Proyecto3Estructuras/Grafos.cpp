// Grafos.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include "Grafo.h"
#include "CargarLondres.h"
#include "Dijkstra.h"
#include "Prim.h"
#include "VarianteDijkstra.h"
#include "AEstrella.h"

int main()
{

    Grafo londres; //crea
    std::string archivoEstaciones = "C:\\Users\\royne\\source\\repos\\Proyecto3Estructuras\\london.stations.csv"; // simple string con la direccion del archivo
    std::string archivoConexiones = "C:\\Users\\royne\\source\\repos\\Proyecto3Estructuras\\london.connections.csv"; //x2.

    CargarLondres cargador(archivoEstaciones, archivoConexiones); //constructor CargarLondres con estos dos strings

    cargador.Cargar(londres); //ejecuta cargar con el grafo londres. dentro llama lectorcsv con ambos strings.

    int bandera = 0;
    std::string sseleccion;
    int seleccion;
    std::cout << "Tons que ak7 ras\n\n";
    while (bandera == 0) 
    {
        std::cout << "Vea mier.\n\nAprete 1 para Dijkstra.\nAprete 2 para Prim.\nAprete 3 para A*\nAprete 4 para una version ak47 de Dijkstra\n\n";
        std::getline(std::cin, sseleccion);
        seleccion = atoi(sseleccion.c_str());
        if (seleccion == 1 || seleccion == 2 || seleccion == 3 || seleccion == 4) 
        {
            bandera = 1;
        }
        else
        {
            std::cout << "\nras pusiste el numero mal, compa\n\n";
        }
    }
    if (seleccion == 1) 
    {
        std::string fuente;
        std::string destino;
        int i_fuente;
        int i_destino;
        bandera = 0;
        while (bandera == 0) 
        {
            std::cout << "ras, ahora di ponga el destino y la fuente\n\n destino: ";
            std::getline(std::cin, destino);
            std::cout << "\n\nfuente: ";
            std::getline(std::cin, fuente);
            if (londres.EncontrarVerticePorNombre(fuente) == -1) 
            {
                std::cout << "\nish bro, esta vara esta mal, pusiste la fuente mal\n\n";
            }
            else if (londres.EncontrarVerticePorNombre(destino) == -1) 
            {
                std::cout << "\nish bro, esta vara esta mal, pusiste el destino mal\n\n";
            }
            else 
            {  
                bandera = 1;
                i_fuente = londres.EncontrarVerticePorNombre(fuente);
                i_destino = londres.EncontrarVerticePorNombre(destino);
            }
        }
        Dijkstra dik;
        dik.Ejecutar(londres, i_fuente);
        std::cout << "\n\n";
        std::cout << dik.RutaMasCortaA(londres, i_destino);
    }
    else if (seleccion == 2)
    {
        std::string fuente;
        int i_fuente;
        bandera = 0;
        while (bandera == 0)
        {
            std::cout << "ras, ahora di ponga la fuente del Prim\n\n fuente: ";
            std::getline(std::cin, fuente);
            if (londres.EncontrarVerticePorNombre(fuente) == -1)
            {
                std::cout << "\nish bro, esta vara esta mal, pusiste la fuente mal\n\n";
            }
            else 
            {
                bandera = 1;
                i_fuente = londres.EncontrarVerticePorNombre(fuente);
            }
        }
        Prim primabela;
        primabela.Ejecutar(londres, i_fuente);
        std::cout << "\n\n";
        std::cout << primabela.ImprimirArbol(londres, i_fuente);
    }
    else if (seleccion == 3)
    {
        std::string fuente;
        std::string destino;
        int i_fuente;
        int i_destino;
        bandera = 0;
        while (bandera == 0)
        {
            std::cout << "ras, ahora di ponga el destino y la fuente\n\n destino: ";
            std::getline(std::cin, destino);
            std::cout << "\n\nfuente: ";
            std::getline(std::cin, fuente);
            if (londres.EncontrarVerticePorNombre(fuente) == -1)
            {
                std::cout << "\nish bro, esta vara esta mal, pusiste la fuente mal\n\n";
            }
            else if (londres.EncontrarVerticePorNombre(destino) == -1)
            {
                std::cout << "\nish bro, esta vara esta mal, pusiste el destino mal\n\n";
            }
            else
            {
                bandera = 1;
                i_fuente = londres.EncontrarVerticePorNombre(fuente);
                i_destino = londres.EncontrarVerticePorNombre(destino);
            }
        }
        AEstrella estrellita;
        estrellita.Ejecutar(londres, i_fuente);
        std::cout << "\n\n";
        std::cout << estrellita.RutaMasCortaA(londres, i_destino);
    }
    else
    {
        std::string fuente;
        std::string destino;
        int i_fuente;
        int i_destino;
        bandera = 0;
        while (bandera == 0)
        {
            std::cout << "ras, ahora di ponga el destino y la fuente\n\n destino: ";
            std::getline(std::cin, destino);
            std::cout << "\n\nfuente: ";
            std::getline(std::cin, fuente);
            if (londres.EncontrarVerticePorNombre(fuente) == -1)
            {
                std::cout << "\nish bro, esta vara esta mal, pusiste la fuente mal\n\n";
            }
            else if (londres.EncontrarVerticePorNombre(destino) == -1)
            {
                std::cout << "\nish bro, esta vara esta mal, pusiste el destino mal\n\n";
            }
            else
            {
                bandera = 1;
                i_fuente = londres.EncontrarVerticePorNombre(fuente);
                i_destino = londres.EncontrarVerticePorNombre(destino);
            }
        }
        VarianteDijkstra VaDiton;
        VaDiton.Ejecutar(londres, i_fuente);
        std::cout << "\n\n";
        std::cout << VaDiton.RutaMasCortaA(londres, i_destino);
    }
    std::cout << "\n\nHasta aqu� llegue, ahora boinas jaleas";




   

   




    
    

    
    
  
}
