#pragma once
#include <string>
#include <list>
#include "Arista.h"
#include "string"
#include <vector>

class Vertice
{

public:
	int Id;
	std::string Nombre;
	double Latitud;
	double Longitud;
	std::vector<Arista> Vecinos;
	Vertice(int id, std::string nombre, double latitud, double longitud);
	~Vertice();

};

