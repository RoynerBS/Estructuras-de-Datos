#include "Grafo.h"

Grafo::Grafo()
{
	Vertices.reserve(500);
	NumeroVertices = 1;
}

Grafo::~Grafo()
{
}

void Grafo::AgregarVertice(int id, std::string nombre, double latitud, double longitud)
{
	Vertices.emplace_back(id, nombre, latitud, longitud);
	NumeroVertices++;
}

void Grafo::AgregarArista(int estacion1, int estacion2,int linea, int tiempo)
{
	
	Vertices[estacion1].Vecinos.emplace_back(estacion2,linea,tiempo);

	Vertices[estacion2].Vecinos.emplace_back(estacion1,linea,tiempo);


}

int Grafo::EncontrarVerticePorNombre(std::string nombre)
{

	int recorrer = 0;
	while (recorrer < Vertices.size()) {
		if (Vertices[recorrer].Nombre == nombre) {
			return recorrer;
		}
		else {
			recorrer += 1;
		}
	}
	return -1;
	//R??

	//TODO: deben completar este mtodo, a partir del nombre devolver su id.
}
