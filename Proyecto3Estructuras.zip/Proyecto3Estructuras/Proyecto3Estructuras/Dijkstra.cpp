#include "Dijkstra.h"

void Dijkstra::Inicializar(Grafo& grafo, int fuente)
{
	int indice = 0;
	while (indice < grafo.Vertices.size()) //no confio en su numero vertices >:c
	{
		if (indice == fuente) 
		{
			TablaGrafos Tablita = TablaGrafos(false, 0, Tablita.ValorVacio());
			indice += 1;
			Tabla.push_back(Tablita);
		}
		else
		{
			TablaGrafos Tablita = TablaGrafos(false, Tablita.ValorDistanciaInfinita(), Tablita.ValorVacio());
			Tabla.push_back(Tablita);
			indice += 1;
		}
	}
	//[indicevertice][visitado][distancia][anteriorid]
	//caso actual [visitado][distancia][anteriorid] : indicevertice tiene que ser di el indice para recorrer, el 0 seria el indice falso que no existe.
	//Ready
	// ver https://docs.google.com/presentation/d/1rQUVSyaPVH2wMr4b_5EBHQ5BGrf8sJ1h/edit#slide=id.p186
}

void Dijkstra::Ejecutar(Grafo& grafo, int fuente)
{
	Inicializar(grafo, fuente);
	while (EncontrarMinimioSinVisitar() != 0) 
	{
		int VerticeActual = EncontrarMinimioSinVisitar();
		Tabla[VerticeActual].Visitado = true;
		int indiceVecino = 0;
		while (indiceVecino < grafo.Vertices[VerticeActual].Vecinos.size())
		{
			if ((Tabla[VerticeActual].Distancia + grafo.Vertices[VerticeActual].Vecinos[indiceVecino].Tiempo) < (Tabla[grafo.Vertices[VerticeActual].Vecinos[indiceVecino].VerticeAdyacente].Distancia))
			{
				Tabla[grafo.Vertices[VerticeActual].Vecinos[indiceVecino].VerticeAdyacente].Distancia = Tabla[VerticeActual].Distancia + grafo.Vertices[VerticeActual].Vecinos[indiceVecino].Tiempo;
				Tabla[grafo.Vertices[VerticeActual].Vecinos[indiceVecino].VerticeAdyacente].Anterior = VerticeActual;
				indiceVecino += 1;
			}
			else 
			{
				indiceVecino += 1;
			}
		
		}
	}
	
	// ver https://docs.google.com/presentation/d/1rQUVSyaPVH2wMr4b_5EBHQ5BGrf8sJ1h/edit#slide=id.p187
}

int Dijkstra::EncontrarMinimioSinVisitar()
{
	int minimo = 2147483647;
	int guardado = 0;
	int indice = 1;
	while (indice < Tabla.size())
	{
		if (Tabla[indice].Visitado == false)
		{
			if (Tabla[indice].Distancia < minimo) 
			{
				minimo = Tabla[indice].Distancia;
				guardado = indice;
				indice += 1;
		
			}
			else 
			{
				indice += 1;
			}
		}
		else
		{
			indice += 1;
		}

	}
	return guardado;
	// ver https://docs.google.com/presentation/d/1rQUVSyaPVH2wMr4b_5EBHQ5BGrf8sJ1h/edit#slide=id.p187

	//Esta es la parte de "Encontramos vrtice v sin visitar con la  minima distancia"
}



std::string Dijkstra::RutaMasCortaA(Grafo& grafo, int destino)
{
	std::string temp;
	int puntoactual = destino;
	int tiempo = Tabla[destino].Distancia;
	while (Tabla[puntoactual].Distancia != 0)
	{
		temp = "---->" + grafo.Vertices[puntoactual].Nombre + temp;
		puntoactual = Tabla[puntoactual].Anterior;
	}
	// https://docs.google.com/presentation/d/1rQUVSyaPVH2wMr4b_5EBHQ5BGrf8sJ1h/edit#slide=id.p234

	// vean la tabla. tienen que comenzar del destino,
	// e "ir hacia atras" hasta que lleguen a la fuente.
	// debe imprimirse en orden (es decir, Fuente, vertice1, vertice2, ... destino)
	//NR
	temp = grafo.Vertices[puntoactual].Nombre + temp + " con un tiempo de: " + std::to_string(tiempo);
	std::stringstream ss(temp);
	return ss.str();
}