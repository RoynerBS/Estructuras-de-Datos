#pragma once
#include <string>
#include "LectorCSV.h"
#include "Grafo.h"

class CargarLondres
{
private:
	std::string ArchivoEstaciones; //tiene un string con la direccion del archivo
	std::string ArchivoConexiones; //x2
public:
	CargarLondres(std::string archivoEstaciones, std::string archivoConexiones); //constructor nada especial
	void Cargar(Grafo& londres); //llama constructor lectorcsv para cargar ambas??
};


