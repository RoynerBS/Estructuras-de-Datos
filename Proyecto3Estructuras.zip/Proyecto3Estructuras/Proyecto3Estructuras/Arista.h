#pragma once
class Arista
{
public:
	int Tiempo;
	int VerticeAdyacente;
	int Linea;
	Arista(int verticeAdyacente,int linea, int tiempo);
};

