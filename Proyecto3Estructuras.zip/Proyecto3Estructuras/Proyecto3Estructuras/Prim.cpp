#include "Prim.h"

void Prim::Inicializar(Grafo& grafo, int fuente)
{
	int indice = 0;
	while (indice < grafo.Vertices.size()) //no confio en su numero vertices >:c
	{
		if (indice == fuente) 
		{
			TablaGrafos Tablita = TablaGrafos(false, 0, Tablita.ValorVacio());
			indice += 1;
			Tabla.push_back(Tablita);
		}
		else
		{
			TablaGrafos Tablita = TablaGrafos(false, Tablita.ValorDistanciaInfinita(), Tablita.ValorVacio());
			Tabla.push_back(Tablita);
			indice += 1;
		}
	}
}

void Prim::Ejecutar(Grafo& grafo, int fuente)
{
	Inicializar(grafo, fuente);
	while (EncontrarMinimioSinVisitar() != 0)
	{
		int VerticeActual = EncontrarMinimioSinVisitar();
		Tabla[VerticeActual].Visitado = true;
		int indiceVecino = 0;
		while (indiceVecino < grafo.Vertices[VerticeActual].Vecinos.size())
		{
			if (grafo.Vertices[VerticeActual].Vecinos[indiceVecino].Tiempo < (Tabla[grafo.Vertices[VerticeActual].Vecinos[indiceVecino].VerticeAdyacente].Distancia))
			{
				Tabla[grafo.Vertices[VerticeActual].Vecinos[indiceVecino].VerticeAdyacente].Distancia = grafo.Vertices[VerticeActual].Vecinos[indiceVecino].Tiempo;
				Tabla[grafo.Vertices[VerticeActual].Vecinos[indiceVecino].VerticeAdyacente].Anterior = VerticeActual;
				indiceVecino += 1;
			}
			else
			{
				indiceVecino += 1;
			}

		}
	}
}

int Prim::EncontrarMinimioSinVisitar()
{
	int minimo = 2147483647;
	int guardado = 0;
	int indice = 1;
	while (indice < Tabla.size())
	{
		if (Tabla[indice].Visitado == false)
		{
			if (Tabla[indice].Distancia < minimo)
			{
				minimo = Tabla[indice].Distancia;
				guardado = indice;
				indice += 1;

			}
			else
			{
				indice += 1;
			}
		}
		else
		{
			indice += 1;
		}

	}
	return guardado;
}

std::string Prim::ImprimirArbol(Grafo& grafo, int fuente)
{ 
	std::string temp = "";
	int indice = 1;
	while (indice < Tabla.size()) 
	{
		temp += grafo.Vertices[indice].Nombre + "---" + grafo.Vertices[Tabla[indice].Anterior].Nombre + "\n";
		indice += 1;
	}
	std::stringstream ss(temp);
	return ss.str();
}

std::vector<int> Prim::Buscar(int puntoactual) 
{
	std::vector<int> respuesta;
	int recorrer = 1;
	while (recorrer < Tabla.size()) 
	{
		if(Tabla[recorrer].Anterior == puntoactual)
		{
			respuesta.push_back(recorrer);
			recorrer += 1;	
		}
		else 
		{
			recorrer += 1;
		
		}
	}
	return respuesta;
}

