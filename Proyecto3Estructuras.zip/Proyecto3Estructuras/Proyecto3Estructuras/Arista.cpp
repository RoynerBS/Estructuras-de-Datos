#include "Arista.h"

Arista::Arista(int verticeAdyacente,int linea ,int tiempo)
{
	Linea = linea;
	Tiempo = tiempo;
	VerticeAdyacente = verticeAdyacente;
}
